<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="47"/>
        <source>初始化</source>
        <translation type="unfinished">Initialization</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="59"/>
        <source>查找设备</source>
        <translation type="unfinished">Serch
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="72"/>
        <source>打开设备</source>
        <translation type="unfinished">Open
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="85"/>
        <source>关闭设备</source>
        <translation type="unfinished">Close
Device</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="99"/>
        <source>图像采集 </source>
        <translation type="unfinished">Image Acquisition</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="111"/>
        <source>开始采集</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>停止采集</source>
        <translation type="unfinished">Stop</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="137"/>
        <source>触发选项</source>
        <translation type="unfinished">Trigger Selector</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="150"/>
        <source>触发开关</source>
        <translation type="unfinished">Trigger Mode</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="163"/>
        <source>触发源</source>
        <translation type="unfinished">Trigger Source</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="206"/>
        <source>执行一次触发</source>
        <translation type="unfinished">Trigger Once</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="229"/>
        <source>图片保存</source>
        <translation type="unfinished">Picture Storage</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="241"/>
        <source>保存BMP</source>
        <translation type="unfinished">Save as
BMP</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="254"/>
        <source>保存JPG</source>
        <translation type="unfinished">Save as
JPG</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="267"/>
        <source>保存tiff</source>
        <translation type="unfinished">Save as
TIFF</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="280"/>
        <source>保存png</source>
        <translation type="unfinished">Save as
PNG</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="294"/>
        <source>参数</source>
        <translation type="unfinished">Parameters</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="306"/>
        <source>像素格式</source>
        <translation type="unfinished">Pixel Format</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="319"/>
        <source>HB模式</source>
        <translation type="unfinished">HB Mode</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="332"/>
        <source>曝光</source>
        <translation type="unfinished">Exposure Time</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="385"/>
        <source>模拟增益</source>
        <translation type="unfinished">Preamp Gain</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="409"/>
        <source>数字增益</source>
        <translation type="unfinished">Digital Shift</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="422"/>
        <source>行频设定值
</source>
        <translation type="unfinished">AcquisitionLine Rate</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="446"/>
        <source>行频使能开关</source>
        <translation type="unfinished">Acquisition Line Rate Enable</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="459"/>
        <source>实际行频</source>
        <translation type="unfinished">Resulting Line Rate</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="482"/>
        <source>参数获取</source>
        <translation type="unfinished">Get
Parameter</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="495"/>
        <source>参数设置</source>
        <translation type="unfinished">Set
Parameter</translation>
    </message>
</context>
</TS>
