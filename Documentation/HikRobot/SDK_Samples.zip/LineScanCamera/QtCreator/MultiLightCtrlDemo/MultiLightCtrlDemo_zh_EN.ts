<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="zh_CN">
<context>
    <name>MultiLightCtrlDemo</name>
    <message>
        <location filename="multilightctrldemo.ui" line="14"/>
        <source>MultiLightCtrlDemo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="140"/>
        <source>用户输入拆分节点数</source>
        <translation type="unfinished">User Input</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="153"/>
        <source>相机节点获取</source>
        <translation type="unfinished">Came Node</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="176"/>
        <source>曝光0</source>
        <translation type="unfinished">Expose0</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="189"/>
        <source>增益0</source>
        <translation type="unfinished">Gain0</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="202"/>
        <source>曝光1</source>
        <translation type="unfinished">Expose1</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="215"/>
        <source>增益1</source>
        <translation type="unfinished">Gain1</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="228"/>
        <source>获取参数</source>
        <translation type="unfinished">Get Param</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="241"/>
        <source>设置参数</source>
        <translation type="unfinished">Set Param</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="289"/>
        <source>图像采集</source>
        <translation type="unfinished">Image Acquisition</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="301"/>
        <source>开始采集</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="314"/>
        <source>停止采集</source>
        <translation type="unfinished">Stop</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="327"/>
        <source>连续模式</source>
        <translation type="unfinished">Continuous</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="340"/>
        <source>触发模式</source>
        <translation type="unfinished">Trigger Mode</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="353"/>
        <source>软触发</source>
        <translation type="unfinished">Trigger by Software</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="366"/>
        <source>软触发一次</source>
        <translation type="unfinished">Trigger Once</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="25"/>
        <source>Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="66"/>
        <source>设备</source>
        <translation type="unfinished">Device</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="78"/>
        <source>枚举设备</source>
        <translation type="unfinished">Enum Device</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="91"/>
        <source>打开设备</source>
        <translation type="unfinished">Open Device</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="104"/>
        <source>关闭设备</source>
        <translation type="unfinished">Close Device</translation>
    </message>
    <message>
        <location filename="multilightctrldemo.ui" line="127"/>
        <source>多灯控制:</source>
        <translation type="unfinished">MultiLight:</translation>
    </message>
</context>
</TS>
